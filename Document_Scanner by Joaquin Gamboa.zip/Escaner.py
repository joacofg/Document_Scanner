import cv2
import imutils
import numpy as np
import pytesseract
from tkinter import filedialog, messagebox
import tkinter as tk

# Crear una ventana raíz para los diálogos
root = tk.Tk()
root.withdraw()

# Función para mostrar los contornos detectados en la imagen
def mostrar_contornos(image, contours):
    contornos_image = image.copy()
    for contour in contours:
        cv2.drawContours(contornos_image, [contour], -1, (0, 255, 0), 2)
    cv2.imshow('Contornos Detectados', contornos_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# Función para ordenar los puntos del contorno del documento
def ordenar_puntos(puntos):
    rect = np.zeros((4, 2), dtype="float32")
    s = puntos.sum(axis=1)
    rect[0] = puntos[np.argmin(s)]
    rect[2] = puntos[np.argmax(s)]
    diff = np.diff(puntos, axis=1)
    rect[1] = puntos[np.argmin(diff)]
    rect[3] = puntos[np.argmax(diff)]
    return rect

# Función para realizar la transformación de perspectiva
def transformacion_perspectiva(image, puntos):
    rect = ordenar_puntos(puntos)
    (tl, tr, br, bl) = rect
    width_a = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
    width_b = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
    max_width = max(int(width_a), int(width_b))

    height_a = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
    height_b = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
    max_height = max(int(height_a), int(height_b))

    destino = np.array([
        [0, 0],
        [max_width - 1, 0],
        [max_width - 1, max_height - 1],
        [0, max_height - 1]], dtype="float32")

    M = cv2.getPerspectiveTransform(rect, destino)
    transformada = cv2.warpPerspective(image, M, (max_width, max_height))
    return transformada

# Función principal para procesar la imagen seleccionada
def procesar_imagen(ruta_imagen):
    try:
        # Leer la imagen desde la ruta seleccionada
        image = cv2.imread(ruta_imagen)
        if image is None:
            raise Exception("No se pudo cargar la imagen. Verifica la ruta o el formato del archivo.")
        
        # Convertir la imagen a escala de grises y aplicar desenfoque
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Detectar bordes en la imagen
        edges = cv2.Canny(gray, 50, 150)  # Ajuste de parámetros para detectar bordes

        # Encontrar y clasificar contornos en la imagen
        contours = cv2.findContours(edges.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        contours = imutils.grab_contours(contours)
        contours = sorted(contours, key=cv2.contourArea, reverse=True)[:5]

        document_contour = None
        for contour in contours:
            peri = cv2.arcLength(contour, True)
            approx = cv2.approxPolyDP(contour, 0.02 * peri, True)
            if len(approx) == 4:
                document_contour = approx
                break

        if document_contour is None:
            raise Exception("No se encontró un contorno de documento adecuado.")

        # Mostrar los contornos detectados
        mostrar_contornos(image, contours)

        # Aplicar la transformación de perspectiva para obtener una vista en planta
        escaneado = transformacion_perspectiva(image, document_contour.reshape(4, 2))

        # Convertir a escala de grises y aplicar umbral para binarizar la imagen
        gray = cv2.cvtColor(escaneado, cv2.COLOR_BGR2GRAY)
        umbralizado = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]

        # Mostrar la imagen escaneada y final
        cv2.imshow('Documento Escaneado', escaneado)
        cv2.imshow('Documento Final', umbralizado)
        cv2.waitKey(0)

        # Guardar la imagen final usando un diálogo de selección de archivo
        nombre_archivo = filedialog.asksaveasfilename(defaultextension=".jpg", filetypes=[("JPEG files", "*.jpg"), ("All files", "*.*")])
        if nombre_archivo:
            cv2.imwrite(nombre_archivo, umbralizado)
            messagebox.showinfo("Éxito", f"Documento guardado como {nombre_archivo}")

        # Convertir la imagen a texto usando OCR
        texto = pytesseract.image_to_string(umbralizado)
        print(texto)

    except Exception as e:
        messagebox.showerror("Error", f"Ocurrió un error: {str(e)}")

# Mostrar el diálogo de selección de archivo para que el usuario seleccione una imagen
ruta_imagen = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg;*.jpeg;*.png"), ("All files", "*.*")])
if ruta_imagen:
    procesar_imagen(ruta_imagen)
